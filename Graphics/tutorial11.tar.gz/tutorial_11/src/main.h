#include "structs.h"

SDL_Surface *screen, *brickImage, *backgroundImage;
Map map;
