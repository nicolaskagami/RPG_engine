#include "defs.h"

typedef struct Map
{
	int tile[MAX_MAP_Y][MAX_MAP_X];
} Map;
